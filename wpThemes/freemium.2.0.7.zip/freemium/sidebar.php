<div class="col-md-4 no-padding-right content-right-sidebar">
            <div class="clearfix"></div>    
            <div class="col-md-12 margin-bottom-3 left-box no-padding main-sidebar">
                <div class="col-md-12 margin-top-bottom-1">
                	
                	<?php dynamic_sidebar('sidebar-1'); ?> 
                    
                </div>
			</div>
     
</div>