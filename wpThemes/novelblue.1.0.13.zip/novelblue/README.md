# novelblue

* Images	 
	 
	License: All unsplash.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/ 	  
	 
		 * images/bg.jpg
			Source: https://download.unsplash.com/photo-1430834500855-3873f1e078f5

		 * images/testimonial1.jpg
			Source: https://download.unsplash.com/7/girl-flowers.jpg
		 
		 * images/testimonial2.jpg
			Source: https://download.unsplash.com/photo-1427096105551-15e2512fd2dc
		  
		 * images/testimonial3.jpg
			Source: https://download.unsplash.com/photo-1428471226620-c2698eadf413

		 * images/about.jpg
		 	Source: https://download.unsplash.com/photo-1431910246269-dc9202bc8a88